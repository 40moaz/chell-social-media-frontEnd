const Navbar = () => {
  return (
    <nav className=" h-16 bg-[#5858FA] text-[#050041] flex items-center justify-center px-6 shadow z-50">
      <div className="text-xl font-bold">Chell</div>
    </nav>
  );
};

export default Navbar;
